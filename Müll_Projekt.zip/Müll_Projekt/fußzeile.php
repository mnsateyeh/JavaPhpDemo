<?php

$fzdummy = '';
$fzdummy = $fzdummy .   '<footer>
                            <p>
                                <h10>
                             &copy;by Matha Ateyeh und Jonas Heldt 2021
                             </h10>
                          </p>
                        </footer>';

echo $fzdummy;

